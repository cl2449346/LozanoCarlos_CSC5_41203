/* Author: Carlos Lozano
 * Created on January 7, 2016, 5:56 PM
 * Purpose: Find the sum of two numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//Starts here
int main(int argc, char** argv) {
    
    //initialize variables
    int x = 50; // first variable
    int y = 100; // second variable
    
    //get the sum of x and y
    int total = x + y;
    
    //Display variables
    cout<<"X = "<< x <<endl;
    cout<<"Y = "<< y <<endl;
    cout<<"Total = "<< total <<endl;
    

    return 0;
}

